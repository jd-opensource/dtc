#include "data_conf_unittest.h"
#include "data_manager_mock.h"

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}