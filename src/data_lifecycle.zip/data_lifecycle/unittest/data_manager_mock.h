#ifndef DATA_MANAGER_MOCK_TEST_H_
#define DATA_MANAGER_MOCK_TEST_H_

#include "unittest_comm.h"
#include "../data_manager.h"

UNITEST_NAMESPACE_BEGIN
class MockDataManager : public DataManager{
public:
    MockDataManager() : DataManager(){
    }
    MockDataManager(const ConfigParam& config_param) : DataManager(config_param) {
    };
    ~MockDataManager(){
    }
    MOCK_METHOD(int, GetLastId, (uint64_t& last_delete_id, std::string& last_invisible_time));
    MOCK_METHOD(int, DoQuery, (const std::string& query_sql, std::vector<QueryInfo>& query_info_vec));
    MOCK_METHOD(int, DoDelete, (const std::string& delete_sql));
    MOCK_METHOD(int, UpdateLastDeleteId, ());
};

class DataManagerTest : public testing::Test {
protected:
    DataManagerTest():data_manager_(&data_manager_mock_){};

    DataManager* data_manager_; 
    MockDataManager data_manager_mock_;
};

TEST_F(DataManagerTest , DoProcessTest){
    EXPECT_CALL(data_manager_mock_ , GetLastId(testing::_, testing::_)).Times(AnyNumber())
        .WillOnce(Return(0)).WillOnce(Return(1))
        .WillRepeatedly(Return(0));

    EXPECT_CALL(data_manager_mock_ , DoQuery(testing::_, testing::_)).Times(AnyNumber())
        .WillRepeatedly(Return(0));

    EXPECT_CALL(data_manager_mock_ , DoDelete(testing::_)).Times(AnyNumber())
        .WillOnce(Return(1)).WillOnce(Return(0))
        .WillRepeatedly(Return(0));

    EXPECT_CALL(data_manager_mock_ , UpdateLastDeleteId()).Times(AnyNumber())
        .WillOnce(Return(1)).WillOnce(Return(0))
        .WillRepeatedly(Return(0));
    data_manager_->SetTimeRule("0 */1 * * * ?");
    EXPECT_NE(0, data_manager_->DoTaskOnce());
}
UNITEST_NAMESPACE_END
#endif