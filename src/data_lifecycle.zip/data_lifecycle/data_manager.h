#ifndef __DATA_MANAGER_H__
#define __DATA_MANAGER_H__

#include <string>
#include <stdint.h>
#include <chrono>
#include <vector>
#include <set>
#include "database_connection.h"
#include "data_conf.h"

class QueryInfo
{
public:
    uint64_t id;
    std::string key_info;
    std::string invisible_time;
};

class DataManager
{
public:
    DataManager();
    DataManager(const ConfigParam& config_param);
    ~DataManager();
    int ConnectAgent();
    int DoProcess();
    int DoTaskOnce();
    void SetTimeRule(const std::string& time_rule);
private:
    int GetLastId(uint64_t& last_delete_id, std::string& last_invisible_time);
    std::string ConstructQuerySql(uint64_t last_delete_id, std::string last_invisible_time);
    int DoQuery(const std::string& query_sql, std::vector<QueryInfo>& query_info_vec);
    std::set<std::string> ConstructDeleteSql(const std::string& key);
    int DoDelete(const std::string& delete_sql);
    int UpdateLastDeleteId();
    std::set<std::string> splitStr(const std::string& src, const std::string& separate_character);
private:
    std::string data_rule_; // example: status=0
    std::string operate_time_rule_; // example: 0 */5 * * * ?
    uint32_t single_query_cnt_;
    std::string table_name_;
    std::string key_field_name_;
    std::string life_cycle_table_name_;
    std::string hot_db_name_;
    std::string cold_db_name_;
    std::time_t next_process_time_;
    CDBConn* db_conn_;
    uint64_t last_delete_id_;
    std::string last_invisible_time_;
};


#endif